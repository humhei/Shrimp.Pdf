﻿namespace Bench
open Expecto
open System
open Workflow.Pdf
open LiteDB
open Workflow.Pdf.Targets
open ExcelProcess
open Workflow.Entities
open Tests.Types
open Input
open Bench.Orders
open Bench.Orders.Order

module Build =
    let productInputs =
        [
        ]

    let parts = __SOURCE_DIRECTORY__.Split([|"\\"|],StringSplitOptions.None)

    let dm: DBModel = 
        {
            CompanyName = parts |> Seq.item (parts.Length - 2)
            TagName = parts |> Seq.last
            OrderNames = ["18SPL86"]
            OrderXLSXName = xlsxName
            SheetGenerator = SheetGenerator.Automatic
            ProductsGenerator = DBModel.generateProducts productInputs
            ItemsGenerator = itemGenerator
        }


