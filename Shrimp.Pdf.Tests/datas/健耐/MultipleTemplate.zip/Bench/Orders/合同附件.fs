namespace Bench.Orders
module Order =
    open Workflow.Pdf
    open Workflow.Entities.Types
    open System.IO
    open ExcelProcess
    open MatrixParsers
    open ArrayParsers
    open SheetParsers
    open FParsec
    open Workflow.Entities
    open XLParser
    open Tests.Types.Input
    type Item =
        inherit IItem
        inherit ISize
        inherit IColor
        inherit IBarcode
        inherit IShippingDate
        inherit IBrand
        inherit IStyle

    let xlsxName s = 
        sprintf "%s%s" s (__SOURCE_FILE__ |> Path.GetFileNameWithoutExtension)

    let itemGenerator (dm:DBModel) orderName sheet =
        let packages = ��װ.packageGenerator dm orderName sheet
        let items = []
        items |> List.map (fun it -> it :> IItem)