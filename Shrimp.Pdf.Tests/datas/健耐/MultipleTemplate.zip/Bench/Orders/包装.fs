﻿namespace Bench.Orders

open Workflow.Entities.Types

[<RequireQualifiedAccess>]
module 包装 = 
    open Workflow.Pdf
    open Workflow.Entities.Types
    open System.IO
    open Workflow.Pdf.Targets
    open System
    open Tests.Types.Input

    type 包装 =
        {
            ColorCard: ColorEnum
            ShippingDate: DateTime
        }

    let packageGenerator (dm:DBModel) orderName sheet =
        []
        